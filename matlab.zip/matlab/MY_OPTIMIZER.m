function xbest = MY_OPTIMIZER(FUN, DIM, ftarget, maxfunevals)
% MY_OPTIMIZER(FUN, DIM, ftarget, maxfunevals)
% samples new points uniformly randomly in [-5,5]^DIM
% and evaluates them on FUN until ftarget of maxfunevals
% is reached, or until 1e8 * DIM fevals are conducted. 

  maxfunevals = min(1e8 * DIM, maxfunevals); 
  popsize = min(maxfunevals, 200);
  fbest = inf;
  xbest = [];
  for iter = 1:ceil(maxfunevals/popsize)
    % Create a matrix with x1,x2...etc between 5-5
    xpop = 10 * rand(DIM, popsize) - 5;      % new solutions
    % In order to avoid checking for sames sets when evaluating the
    % function in order to find the minimum value, a temporary matrix is
    % created by using the unique function
    xpoptemp = unique(xpop','rows')';
    % Evaluate the function FUN from the input matrix
    fvalues = feval(FUN,xpoptemp);
    % Loop through the inputs and find the solution with the minimum fvalue
    % Create a cell array to store information about the index of the xpop
    % table that the minimum value was found, the values of xpop and the
    % fvalue at the same position along with the difference from the
    % ftarget
    info = cell(0,1);
    % Create a new counter to hold how many times did we find a minimum
    iterations = 1;
    for i = 1:length(xpoptemp)
        % if the latest fvalue is less than the best minimum from previous
        % iterations
        if fvalues(i) < fbest
            % Set the new fbest and xbest
            fbest = fvalues(i);
            xbest = xpoptemp(:,i);
            % Store information and print a log message
            info{iterations,1} = i;
            info{iterations,2} = xbest;
            info{iterations,3} = fbest;
            info{iterations,4} = abs(fbest - ftarget);
            fprintf('Best solution found in table position %d with fvalue = %f. Difference from ftarget = %f\n',i,fbest,info{iterations,4})
            iterations = iterations + 1;
        end
        if feval(FUN, 'fbest') < ftarget         % COCO-task achieved
            break;                                 % (works also for noisy functions)
        end
       
    end
    % When optimization has finished try and find the minimum starting from
    % the xbest.
        [X,fval] = fminsearch(FUN,xbest);
  end 

  
